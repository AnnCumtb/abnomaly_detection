# 根据json&raw 序列化生成快照(snapshot)的示例教程
# 仅支持BY阶段网络
# 在device，backend的各项配置请在save snapshot前进行调用
# 完成session.apply之后 生成snapshot
from icraft.xir import * 
from icraft.xrt import * 
from icraft.host_backend import *
from icraft.buyibackend import * 
# 开启device
URL_PATH =  R"socket://ql100aiu@192.168.125.184:9981?npu=0x40000000&dma=0x80000000"
# URL_PATH = R"mock://ql100ai?npu=0x40000000&dma=0x80000000"
# # 如果不方便连接开发板，请使用此url，即可不连接板子生成快照; icraft v3.5以后生效
device = Device.Open(URL_PATH)
print('INFO:open device at:',URL_PATH) 
# 默认加载yolov5s_hard的json&raw文件，如需生成yolov5s_soft,请手动修改
GENERATED_JSON_FILE = "../imodel/yolov5s_hard/yolov5s_BY.json"
GENERATED_RAW_FILE = "../imodel/yolov5s_hard/yolov5s_BY.raw"
snapshot_file = R'yolov5s_hard.snapshot' #生成的快照文件名
# 加载指令生成后的网络
generated_network = Network.CreateFromJsonFile(GENERATED_JSON_FILE)
generated_network.loadParamsFromFile(GENERATED_RAW_FILE)
print('INFO: Create network!')
host_device = HostDevice.Default()
session = Session.Create([BuyiBackend,HostBackend],generated_network.view(0),[device,host_device])
# 只能buyibackend+hostbackend，也就是必须上板,不能纯host_backend
session.apply()

#序列化session生成快照文件，并保存快照文件至指定路径
session.dumpSnapshot(snapshot_file)
print('Snapshot save at:',snapshot_file)

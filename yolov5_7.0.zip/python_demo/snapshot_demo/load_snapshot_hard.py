# deserialize demo
# 用snapshot文件反序列化得到session,并进行推理的示例教程
import cv2
import numpy as np
import sys
sys.path.append('../')
from icraft.xir import * 
from icraft.xrt import * 
from icraft.host_backend import *
from icraft.buyibackend import * 
from preprocess import letterbox,scale_coords
from utils import dmaInit,getOutputNormratio
from detpost_hard import soft_nms,get_det_results
from visualize import vis,COCO_CLASSES

# 开启device
URL_PATH =  R"socket://ql100aiu@192.168.125.184:9981?npu=0x40000000&dma=0x80000000"
device = Device.Open(URL_PATH)
print('INFO:open device at:',URL_PATH) 
# 由快照文件构建session，并完成apply部署
# 请确保已存在yolov5s_hard.snapshot文件
snapshot_file = R'yolov5s_hard.snapshot'
session = Session.CreateWithSnapshot(snapshot_file, [BuyiBackend, HostBackend ], [ device, HostDevice.Default() ])

# 加载测试图像并转成icraft.Tensor
IMG_PATH="../images/000000000885.jpg" 
img=cv2.imread(IMG_PATH)
ri = letterbox(img,new_shape=(640,640),stride=32,auto=False)[0]
img_=ri.reshape(1,640,640,3)
input_tensor = Tensor(img_, Layout("NHWC"))
print('INFO: load test image!')

# dma init
IMK = True 
print('IMK =',IMK) #获取网络中是否使用了IMK硬算子
dmaInit(device,input_tensor,[640,640,3],IMK) #如果使用了IMK硬算子，进行对应配置
print('dmaInit done')

# 前向，获取输出
output_tensors = session.forward([ input_tensor ])

# 养成良好的使用习惯，网络前向结束后，重置device
device.reset(0)

generated_output = []
for tensor in output_tensors:
    generated_output.append(np.asarray(tensor.to(HostDevice.MemRegion())))#data transfer2 [udma->ps]  

print('anchor_0 shape =',np.array(generated_output[0]).shape) # [1,1,152,96]
print('anchor_1 shape =',np.array(generated_output[1]).shape) # [1,1,100,96]
print('anchor_2 shape =',np.array(generated_output[2]).shape) # [1,1,56,96]
print('INFO: get icore results!')
# Step1: 因为icore_post输出的是定点结果，所以需要读取norm_ratio，对定点结果进行反量化
# 从session中创建network，从network中获取反量化系数
network = session.backends[0].network_view.network()
scale_list = getOutputNormratio(network)
print("output scale =",scale_list)
print('INFO: get scale results!')  
# Step 2: 将icore_post结果转化为box_list,scores_list,id_list
scores_list,box_list,id_list = get_det_results(generated_output,scale_list)
print('INFO: get detection results!') 
# Step 3: NMS 取NMS后的结果
nms_indices,nms_box_list,nms_score_list,nms_cls_ids = soft_nms(box_list, scores_list, id_list)
print('nms_indices =',nms_indices)
print('INFO: get NMS results!') 
# ---------------------------------结果可视化---------------------------------
nms_box_list = scale_coords(img_.shape[1:], np.array(nms_box_list), img.shape)
result_image = vis(img,boxes=nms_box_list,scores=nms_score_list,cls_ids=nms_cls_ids,conf=0.25,class_names=COCO_CLASSES)
cv2.imshow(" ", result_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

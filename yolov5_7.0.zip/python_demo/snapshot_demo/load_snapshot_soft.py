# deserialize demo
# 用snapshot文件反序列化得到session,并进行推理的示例教程
import cv2
import numpy as np
import sys
sys.path.append('../')
from icraft.xir import * 
from icraft.xrt import * 
from icraft.host_backend import *
from icraft.buyibackend import * 
from preprocess import letterbox,scale_coords
from detpost_soft import get_det_results,non_max_suppression
from visualize import vis,COCO_CLASSES

# 开启device
URL_PATH =  R"socket://ql100aiu@192.168.125.184:9981?npu=0x40000000&dma=0x80000000"
device = Device.Open(URL_PATH)
print('INFO:open device at:',URL_PATH) 
# 由快照文件构建session，并完成apply部署
# 请确保已存在yolov5s_soft.snapshot文件
snapshot_file = R'yolov5s_soft.snapshot'
session = Session.CreateWithSnapshot(snapshot_file, [BuyiBackend, HostBackend ], [ device, HostDevice.Default() ])

# 加载测试图像并转成icraft.Tensor
IMG_PATH="../images/000000000885.jpg" 
img=cv2.imread(IMG_PATH)
ri = letterbox(img,new_shape=(640,640),stride=32,auto=False)[0]
img_=ri.reshape(1,640,640,3)
input_tensor = Tensor(img_, Layout("NHWC"))
print('INFO: load test image!')

# 前向，获取输出
generated_output = session.forward([ input_tensor ])

# 养成良好的使用习惯，网络前向结束后，重置device
device.reset(0)

print('anchor_0 shape =',np.array(generated_output[0]).shape) # [1,80,80,255]
print('anchor_1 shape =',np.array(generated_output[1]).shape) # [1,40,40,255]
print('anchor_2 shape =',np.array(generated_output[2]).shape) # [1,20,20,255]
print('INFO: get forward results!')

# ---------------------------------后处理---------------------------------
# from socket results to det results 
pred = get_det_results(generated_output)
print("INFO: pred shape =",pred.shape)
# NMS
pred = non_max_suppression(pred,classes=None, agnostic=False, max_det=1000)

# ---------------------------------结果可视化---------------------------------
det = pred[0]
det[:, :4] = scale_coords(img_.shape[1:], det[:, :4], img.shape).round()
result_image = vis(img, boxes=det[:,:4], scores=det[:,4], cls_ids=det[:,5], conf=0.25, class_names=COCO_CLASSES)
cv2.imshow(" ", result_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
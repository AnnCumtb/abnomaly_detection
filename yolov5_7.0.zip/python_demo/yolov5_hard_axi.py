# 带硬算子的axi脚本,可直接在板子上运行。 
 
# 首先import相关的包，分为三部分， 框架下相关包，icraft相关包，模型的前后处理、可视化   
import numpy as np
import cv2
import os

from icraft.xir import *          # xir:Icraft-XIR的python模块
from icraft.xrt import *          # xrt:Icraft-XIR的python模块(runtime运行时)
from icraft.host_backend import * # host_backend:Icraft-HostBackend的python模块
from icraft.buyibackend import *  # buyibackend:Icraft-BuyiBackend的python模块

from utils import dmaInit,fpgaOPlist,getOutputNormratio # utils:功能函数模块，主要用来获取量化参数scale_list、使能IMK硬算子等
from detpost_hard import soft_nms,get_det_results                   # detpost_hard:配硬算子的后处理模块，注意这里的后处理，已经是对应硬算子的后处理（detpost_hard）了，请注意区分。
from visualize import vis,COCO_CLASSES                              # visualize:结果可视化模块
from preprocess import letterbox,scale_coords                       # preprocess:前处理模块
from calctime_ultis import *                                        # calctime_ultis:网络时间分析模块
# ---------------------------------参数设置---------------------------------
# 声明一些文件路径，主要是板子ip地址、icraft编译后的指令生成网络（json&raw文件）、测试图片   
URL_PATH =  R"axi://ql100aiu?npu=0x40000000&dma=0x80000000"  # 注意此时axi对应的板子ip已经发生了变化
GENERATED_JSON_FILE = "./imodel/yolov5s_hard/yolov5s_BY.json"
GENERATED_RAW_FILE = "./imodel/yolov5s_hard/yolov5s_BY.raw"
IMG_PATH="./images/000000000885.jpg" 
TIME_PATH = 'hard_times.xlsx'

# 下面是最主要的模型前向过程，分为以下几个步骤   
# 1.开启device
# 2.加载指令生成后的网络
# 3.创建session并将整个网络绑定到BuyiBackend和HostBackend，使用Buyi_device和HostDevice
# 4.加载测试图像并转成icraft.Tensor
# 5.配置IMK，将ps端数据搬移至udma buffer （这一步不要忘记哦，否则会引起错误哦）
# 6.模型前向推理
# --------------------------1.开启deviceopen device---------------------------------------
device = Device.Open(URL_PATH)
print('INFO:open device at:',URL_PATH) 
# --------------------------2.加载指令生成后的网络-----------------------------------------
generated_network = Network.CreateFromJsonFile(GENERATED_JSON_FILE)
generated_network.loadParamsFromFile(GENERATED_RAW_FILE)
print('INFO: Create network!')

# --------------------------3.创建session并将整个网络绑定到BuyiBackend和HostBackend---------
session = Session.Create([ BuyiBackend, HostBackend], generated_network.view(1), [ device,HostDevice.Default()])
session.enableTimeProfile(True) #打开计时功能
session.apply()
# --------------------------4.加载测试图像并转成icraft.Tensor-----------------------------
img=cv2.imread(IMG_PATH)
ri = letterbox(img,new_shape=(640,640),stride=32,auto=False)[0] #ndarray of shape [640,640,3]
img_=ri.reshape(1,640,640,3)
input_tensor = Tensor(img_, Layout("NHWC"))
print('INFO: load test image!')
# ---------------------------5.配置IMK，将ps端数据搬移至udma buffer------------------------
customop_set=fpgaOPlist(generated_network)
print(customop_set)
IMK = True if "customop::ImageMakeNode" in customop_set else False
print('IMK =',IMK)
dmaInit(device,input_tensor,[640,640,3],IMK)
print('dmaInit done')
# ---------------------------6.模型前向推理-----------------------------------------------
output_tensors = session.forward( [input_tensor] )
# 建议养成良好的使用习惯，每次session.forward后重置device，确保连续测试不同图像的正确性。
device.reset(1)

generated_output = []
for tensor in output_tensors:
    generated_output.append(np.asarray(tensor.to(HostDevice.MemRegion())))#data transfer2 [udma->ps]  
# 此时，我们就获得了模型前向推理的结果，可以看一下三个检测头的输出结果！
# 由于结果还在udma buffer中，需要调用tensor.to方法将输出结果从udma buffer搬运至ps端进行后续处理，这一步不要忘记哦
# 请关注上面tensor.to(rt.HostDevice.MemRegion())的使用
print('anchor_0 shape =',np.array(generated_output[0]).shape) # [1,1,152,96]
print('anchor_1 shape =',np.array(generated_output[1]).shape) # [1,1,100,96]
print('anchor_2 shape =',np.array(generated_output[2]).shape) # [1,1, 56,96]
print('INFO: get icore results!')

# -------------------------------后处理-------------------------------
# 要针对硬件输出的layout进行数据排布的转换，将icore_post的结果转化为检测结果。
# 后处理一共包含3步，分别是：   
# Step 1: 读取norm_ratio，对定点结果进行反量化
# Step 2: 将icore_post结果转化为box_list,scores_list,id_list
# Step 3: 进行非极大值抑制，取NMS后的结果

# Step 1: 读取norm_ratio，对定点结果进行反量化
scale_list = getOutputNormratio(generated_network)
print('INFO: get scale results!')  
print(scale_list)
# Step 2: 将icore_post结果转化为box_list,scores_list,id_list
# 主要是根据硬件的数据排布格式，从[x,96]维度的icore_post硬件输出中计算x,y,w,h坐标
# Step 1中提取的量化scale也在本步骤中对定点结果进行反量化，因此输出已经是浮点结果。
# 有兴趣的可自行查看封装好的get_det_results和soft_nms函数内部实现过程。
scores_list,box_list,id_list = get_det_results(generated_output,scale_list)
print('INFO: get detection results!') 
# Step 3: NMS 取NMS后的结果
nms_indices,nms_box_list,nms_score_list,nms_cls_ids = soft_nms(box_list, scores_list, id_list)
print('nms_indices =',nms_indices)
print('INFO: get NMS results!') 
# Step 4:结果可视化
nms_box_list = scale_coords(img_.shape[1:], np.array(nms_box_list), img.shape)
result_image = vis(img,boxes=nms_box_list,scores=nms_score_list,cls_ids=nms_cls_ids,conf=0.25,class_names=COCO_CLASSES)
output_path = IMG_PATH.replace('images','images_output').replace('.jpg','_result.jpg')
result_path = output_path[:output_path.rfind("/")]
if not os.path.exists(result_path):
    #创建结果文件夹
    os.makedirs(result_path)
    print("文件夹已创建")
else:
    print("文件夹已存在")
cv2.imwrite(output_path,result_image)
print('result save at',output_path)
# -------------------------------模型时间统计结果-------------------------------
# Icraft还提供了计时功能，可以方便地对网络的整体运行时间进行统计，让我们来一起体验一下吧！   
# 在创建网络session时提供了计时功能的开关   
# 设置session.enableTimeProfile(True) 表示打开计时功能   
# 接下来让我们获取统计到的时间信息  
print('*'*80)
# 模型时间信息统计
calctime_detail(session,generated_network, name=TIME_PATH)#获取时间信息并保存时间结果
print('Time result save at',TIME_PATH)
# 在TIME_PATH下已经保存了时间统计结果，包括网络的总运行时间（total_totaltime）、数据搬移时间(total_memcpytime)、硬件处理时间(total_hardtime)、剩余时间(total_othertime)
# 详细的时间分析结果请参考tutorial/time_analysis节
# 关闭设备
Device.Close(device) 
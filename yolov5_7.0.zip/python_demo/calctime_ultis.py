import pandas as pd #need pandas version == 1.3.5
import numpy as np


def save_time(network, times, filenames):
    # times为字典，"op_id":[总时间，传输时间, 硬件时间，余下时间]
    # 保存每一层op_id、op_name、op_type、时间
    list_keys = sorted(times.keys())
    op_name= np.array([network.getOpById(op_id).name.replace("Node","")  for op_id in list_keys])
    op_type = np.array([network.getOpById(op_id).typeKey().replace("Node","")  for op_id in list_keys])
    list_values  = np.array([list(times[op_id])  for op_id in list_keys])
    total_time = list_values[:,0]
    memcpy_time = list_values[:,1]
    hard_time = list_values[:,2]
    other_time = list_values[:,3]
    dict_time = {"op_id":list_keys,"op_name":op_name,"op_type":op_type,"total_time":total_time,"memcpy_time":memcpy_time,"hard_time":hard_time,"other_time":other_time}
    pf=pd.DataFrame(dict_time)
    file_path=pd.ExcelWriter(filenames)
    pf.to_excel(file_path, encoding='utf-8', index=False)
    file_path.save()
    return dict_time


def calctime_detail(sess, network, name="time_results.xlsx"):
    # 计算时间, 输入：session、network、保存表名
    result = sess.timeProfileResults() #获取时间，[总时间，传输时间, 硬件时间，余下时间]
    net_dict = save_time(network,result,name)
    # 统计所有op的各项时间
    time = np.array(list(result.values()))
    total_totaltime = np.sum(time[:,0])
    total_memcpytime = np.sum(time[:,1])
    total_hardtime = np.sum(time[:,2])
    total_othertime = np.sum(time[:,3])
    print("Total_TotalTime:{:.4f} ms, Total_MemcpyTime:{:.4f} ms, Total_HardTime:{:.4f} ms, Total_OtherTime:{:.4f} ms".format(total_totaltime,total_memcpytime,total_hardtime,total_othertime))
   
    hardop_totaltime,hardop_memcpytime,hardop_hardtime = 0,0,0
    customops = {"customop_name":[], "total_time":[],"hard_time":[]}
    for i in range(len(net_dict["op_type"])):
        # 统计所有hardop的totaltime&hardop_hardtime
        if net_dict["op_type"][i] == "icraft::xir::HardOp":
            hardop_totaltime += net_dict["total_time"][i]
            hardop_memcpytime += net_dict["memcpy_time"][i]
            hardop_hardtime += net_dict["hard_time"][i]
        # 统计所有customop的totaltime&hardop_hardtime
        if net_dict["op_type"][i].split("::")[0] == "customop":
            op_name = net_dict["op_type"][i].split("::")[1]
            if op_name not in customops["customop_name"]:
                customops["customop_name"].append(op_name)
                customops["total_time"].append(net_dict["total_time"][i])
                customops["hard_time"].append(net_dict["hard_time"][i])
            else:
                index = customops["customop_name"].index(op_name)
                customops["total_time"][index] = net_dict["total_time"][i]
                customops["hard_time"][index] = net_dict["hard_time"][i]

    hardop_totaltime -= hardop_memcpytime
    print("Hardop_TotalTime:{:.4f} ms, Hardop_HardTime:{:.4f} ms".format(hardop_totaltime,hardop_hardtime))

    for i in range(len(customops["customop_name"])):
        print("Customop:{}, TotalTime:{:.4f}ms, HardTime:{:.4f}ms".format(customops["customop_name"][i],customops["total_time"][i],customops["hard_time"][i]))
    print("For details about running time meassage of the network, check the ", name)

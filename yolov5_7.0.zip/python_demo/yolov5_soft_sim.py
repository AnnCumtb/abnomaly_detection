import torch 
import numpy as np 
import cv2 

from icraft.xir import * 
from icraft.xrt import * 
from icraft.host_backend import *
from icraft.buyibackend import * 

from preprocess import letterbox,scale_coords
from detpost_soft import get_det_results,non_max_suppression
from visualize import vis,COCO_CLASSES
# ---------------------------------参数设置---------------------------------
# 路径设置 
GENERATED_JSON_FILE = "../imodel/8/yolov5s_BY.json"
GENERATED_RAW_FILE = "../imodel/8/yolov5s_BY.raw"
IMG_PATH="./images/bus.jpg"
# 加载测试图像并转成icraft.Tensor
img = cv2.imread(IMG_PATH)
ri = letterbox(img,new_shape=(640,640),stride=32,auto=False)[0]
img_ = ri.astype(np.float32).reshape(1,640,640,3)
input_tensor = Tensor(img_,Layout("NHWC"))
print('INFO: load test image!')
# 加载指令生成后的网络
generated_network = Network.CreateFromJsonFile(GENERATED_JSON_FILE)
generated_network.loadParamsFromFile(GENERATED_RAW_FILE)
print('INFO: Create network!')
# 创建Session
session = Session.Create([HostBackend],generated_network.view(0),[HostDevice.Default()])
session.apply()
# 模型前向推理
generated_output = session.forward([input_tensor])
print('anchor_0 shape =',np.array(generated_output[0]).shape) # [1,80,80,255]
print('anchor_1 shape =',np.array(generated_output[1]).shape) # [1,40,40,255]
print('anchor_2 shape =',np.array(generated_output[2]).shape) # [1,20,20,255]
print('INFO: get forward results!')
# ---------------------------------后处理---------------------------------
#  from sim results to det results
pred = get_det_results(generated_output)
print('pred =',pred,pred.shape)
print("INFO: pred shape =",pred.shape)
# NMS
pred = non_max_suppression(pred, classes=None, agnostic=False, max_det=1000)

# ---------------------------------结果可视化---------------------------------
det = pred[0]
det[:, :4] = scale_coords(img_.shape[1:], det[:, :4], img.shape).round()
result_image = vis(img, boxes=det[:,:4], scores=det[:,4], cls_ids=det[:,5], conf=0.25, class_names=COCO_CLASSES)
cv2.imshow(" ", result_image)
cv2.waitKey(0)
cv2.destroyAllWindows()